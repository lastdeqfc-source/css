extends CharacterBody3D

var hp := 100
var armor := 0
var money := 800
var kills := 0
var move_vec := Vector2.ZERO
var pitch := 0.0
var crouch := false
var firing := false
var want_jump := false
var reloading := false
var cooldown := 0.0
var hurt_t := 0.0
var cur := 0
var spawn := Vector3.ZERO
var cam: Camera3D
var gun: MeshInstance3D
var hud
var sfx: AudioStreamPlayer

var weapons := [
	{"name": "AK-47", "dmg": 34, "rate": 0.1, "mag": 30, "res": 90, "recoil": 1.3, "reload": 2.4},
	{"name": "Glock-18", "dmg": 22, "rate": 0.22, "mag": 20, "res": 60, "recoil": 0.7, "reload": 1.8},
]
var ammos := [30, 20]
var reserves := [90, 60]

func _ready() -> void:
	add_to_group("player")
	spawn = position
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	cam = Camera3D.new()
	cam.position.y = 1.6
	cam.fov = 75
	add_child(cam)
	gun = MeshInstance3D.new()
	var gm := BoxMesh.new()
	gm.size = Vector3(0.07, 0.1, 0.55)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.2, 0.22)
	gm.material = mat
	gun.mesh = gm
	gun.position = Vector3(0.22, -0.22, -0.5)
	cam.add_child(gun)
	sfx = AudioStreamPlayer.new()
	sfx.stream = _make_shot()
	add_child(sfx)
	var cl := CanvasLayer.new()
	add_child(cl)
	hud = preload("res://scripts/hud.gd").new()
	hud.player = self
	cl.add_child(hud)

func _make_shot() -> AudioStreamWAV:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = 22050
	var n := 3500
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var v := int(randf_range(-1.0, 1.0) * 22000.0 * pow(1.0 - float(i) / n, 3.0))
		data.encode_s16(i * 2, v)
	s.data = data
	return s

func rotate_look(rel: Vector2) -> void:
	if hp <= 0:
		return
	rotation.y -= rel.x * 0.004
	pitch = clamp(pitch - rel.y * 0.004, -1.4, 1.4)
	cam.rotation.x = pitch

func press(role: String, down: bool) -> void:
	if hp <= 0:
		if down:
			respawn()
		return
	match role:
		"fire": firing = down
		"jump":
			if down: want_jump = true
		"crouch": crouch = down
		"reload":
			if down: reload()
		"swap":
			if down: swap()
		"buy":
			if down: buy()

func swap() -> void:
	cur = 1 - cur
	var gm: BoxMesh = gun.mesh
	gm.size = Vector3(0.07, 0.1, 0.55) if cur == 0 else Vector3(0.06, 0.1, 0.25)

func buy() -> void:
	if money >= 650 and armor < 100:
		money -= 650
		armor = 100

func reload() -> void:
	var i := cur
	if reloading or ammos[i] >= weapons[i].mag or reserves[i] <= 0:
		return
	reloading = true
	await get_tree().create_timer(weapons[i].reload).timeout
	var take: int = min(weapons[i].mag - ammos[i], reserves[i])
	ammos[i] += take
	reserves[i] -= take
	reloading = false

func shoot() -> void:
	var w = weapons[cur]
	if reloading:
		return
	if ammos[cur] <= 0:
		reload()
		return
	ammos[cur] -= 1
	cooldown = w.rate
	sfx.play()
	pitch = clamp(pitch + w.recoil * 0.012, -1.4, 1.4)
	cam.rotation.x = pitch
	rotation.y += randf_range(-1.0, 1.0) * w.recoil * 0.004
	gun.position.z = -0.42
	var b := cam.global_transform.basis
	var dir := (-b.z + b.x * randf_range(-0.01, 0.01) + b.y * randf_range(-0.01, 0.01)).normalized()
	var from := cam.global_position
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 80.0)
	q.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		var c = hit.collider
		if c.has_method("take_damage"):
			c.take_damage(w.dmg, self)
			hud.hitmark = 0.15
		_spark(hit.position)

func _spark(p: Vector3) -> void:
	var m := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = 0.06
	s.height = 0.12
	m.mesh = s
	get_parent().add_child(m)
	m.global_position = p
	get_tree().create_timer(0.12).timeout.connect(m.queue_free)

func take_damage(d: float, _from = null) -> void:
	if hp <= 0:
		return
	if armor > 0:
		var absorbed := d * 0.5
		armor = int(max(0, armor - absorbed))
		d -= absorbed
	hp -= int(d)
	hurt_t = 0.3
	if hp <= 0:
		hp = 0
		firing = false
		move_vec = Vector2.ZERO

func respawn() -> void:
	hp = 100
	armor = 0
	position = spawn
	velocity = Vector3.ZERO
	ammos = [30, 20]
	reserves = [90, 60]
	reloading = false
	money = max(money, 800)

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	if hp <= 0:
		velocity.x = 0
		velocity.z = 0
		move_and_slide()
		return
	cooldown -= delta
	hurt_t = max(0.0, hurt_t - delta)
	var dir := transform.basis * Vector3(move_vec.x, 0, move_vec.y)
	var spd := 3.0 if crouch else 6.0
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	if want_jump and is_on_floor():
		velocity.y = 6.0
	want_jump = false
	move_and_slide()
	cam.position.y = lerp(cam.position.y, 1.0 if crouch else 1.6, 10.0 * delta)
	gun.position.z = lerp(gun.position.z, -0.5, 12.0 * delta)
	if firing and cooldown <= 0.0:
		shoot()
