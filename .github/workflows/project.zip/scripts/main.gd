extends Node3D

const SAND := Color(0.76, 0.68, 0.5)
const WALL := Color(0.65, 0.55, 0.4)
const CRATE := Color(0.5, 0.35, 0.2)

func _ready() -> void:
	randomize()
	_env()
	_build_map()
	var player = preload("res://scripts/player.gd").new()
	player.position = Vector3(-22, 1, 24)
	add_child(player)
	for p in [Vector3(22, 1, -24), Vector3(8, 1, -12), Vector3(-20, 1, -20)]:
		var b = preload("res://scripts/bot.gd").new()
		b.position = p
		b.target = player
		add_child(b)

func _env() -> void:
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.55, 0.7, 0.85)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.75, 0.75, 0.75)
	e.ambient_light_energy = 0.8
	we.environment = e
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 30, 0)
	sun.light_energy = 0.9
	add_child(sun)

func _box(pos: Vector3, size: Vector3, col: Color) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	bm.material = mat
	mi.mesh = bm
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	body.add_child(cs)
	add_child(body)

func _build_map() -> void:
	_box(Vector3(0, -0.5, 0), Vector3(62, 1, 62), SAND)
	_box(Vector3(0, 3, -30.5), Vector3(63, 6, 1), WALL)
	_box(Vector3(0, 3, 30.5), Vector3(63, 6, 1), WALL)
	_box(Vector3(-30.5, 3, 0), Vector3(1, 6, 63), WALL)
	_box(Vector3(30.5, 3, 0), Vector3(1, 6, 63), WALL)
	# центр и две стены, образующие проходы
	_box(Vector3(0, 2, 0), Vector3(8, 4, 8), WALL)
	_box(Vector3(-12, 2, -8), Vector3(1, 4, 28), WALL)
	_box(Vector3(12, 2, 8), Vector3(1, 4, 28), WALL)
	# ящики
	for p in [Vector3(4, 1, 12), Vector3(-5, 1, 14), Vector3(-20, 1, 10), Vector3(20, 1, -10),
			Vector3(6, 1, -14), Vector3(-6, 1, -16), Vector3(22, 1, 18), Vector3(-22, 1, -12)]:
		_box(p, Vector3(2, 2, 2), CRATE)
