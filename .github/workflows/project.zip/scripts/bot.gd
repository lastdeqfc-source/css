extends CharacterBody3D

var target
var hp := 100
var shoot_cd := 1.5
var t := 0.0
var body_mat: StandardMaterial3D
var spawns := [Vector3(22, 1, -24), Vector3(8, 1, -12), Vector3(-20, 1, -20), Vector3(24, 1, -4), Vector3(-4, 1, -26)]

func _ready() -> void:
	add_to_group("bots")
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	var mi := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.4
	cm.height = 1.8
	body_mat = StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.7, 0.4, 0.15)
	cm.material = body_mat
	mi.mesh = cm
	mi.position.y = 0.9
	add_child(mi)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.2
	sm.height = 0.4
	var hm := StandardMaterial3D.new()
	hm.albedo_color = Color(0.9, 0.75, 0.6)
	sm.material = hm
	head.mesh = sm
	head.position = Vector3(0, 1.75, -0.1)
	add_child(head)

func take_damage(d: float, from = null) -> void:
	hp -= int(d)
	body_mat.albedo_color = Color(1, 0.1, 0.1)
	get_tree().create_timer(0.1).timeout.connect(func(): body_mat.albedo_color = Color(0.7, 0.4, 0.15))
	if hp <= 0:
		if from != null and "money" in from:
			from.money += 300
			from.kills += 1
		hp = 100
		position = spawns[randi() % spawns.size()]
		shoot_cd = 1.5

func _los() -> bool:
	var q := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 1.5, 0), target.global_position + Vector3(0, 1.2, 0))
	q.exclude = [get_rid()]
	var h := get_world_3d().direct_space_state.intersect_ray(q)
	return not h.is_empty() and h.collider == target

func _physics_process(delta: float) -> void:
	t += delta
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	if target == null or target.hp <= 0:
		velocity.x = 0
		velocity.z = 0
		move_and_slide()
		return
	var to_t: Vector3 = target.global_position - global_position
	var flat := Vector3(to_t.x, 0, to_t.z)
	var dist := flat.length()
	var los := _los()
	if dist > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-flat.x, -flat.z), 5.0 * delta)
		var d := flat.normalized()
		var move := Vector3.ZERO
		if dist > 9.0 or not los:
			move = d * 3.5
		else:
			move = d.cross(Vector3.UP) * sin(t * 1.5) * 2.0
		velocity.x = move.x
		velocity.z = move.z
	move_and_slide()
	shoot_cd -= delta
	if los and dist < 40.0 and shoot_cd <= 0.0:
		shoot_cd = randf_range(0.4, 0.8)
		if randf() < 0.4:
			target.take_damage(14.0, self)
