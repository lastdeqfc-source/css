extends Control

var player
var hitmark := 0.0
var touches := {}
var joy_center := Vector2(200, 500)
var joy_pos := Vector2(200, 500)
var buttons := {}
const GOLD := Color(1.0, 0.85, 0.2)

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layout()

func _layout() -> void:
	var s := get_viewport_rect().size
	buttons = {
		"fire": [Vector2(s.x * 0.88, s.y * 0.60), 70.0, "FIRE"],
		"jump": [Vector2(s.x * 0.76, s.y * 0.82), 46.0, "JUMP"],
		"crouch": [Vector2(s.x * 0.93, s.y * 0.86), 40.0, "DUCK"],
		"reload": [Vector2(s.x * 0.72, s.y * 0.58), 40.0, "R"],
		"swap": [Vector2(s.x * 0.62, s.y * 0.78), 38.0, "SWAP"],
		"buy": [Vector2(s.x * 0.10, s.y * 0.20), 36.0, "BUY"],
	}

func _hit(p: Vector2) -> String:
	for k in buttons:
		if p.distance_to(buttons[k][0]) <= buttons[k][1] * 1.2:
			return k
	if p.x < get_viewport_rect().size.x * 0.45:
		return "joy"
	return "look"

func _input(e: InputEvent) -> void:
	if player == null:
		return
	if e is InputEventScreenTouch:
		if e.pressed:
			var role := _hit(e.position)
			touches[e.index] = role
			if role == "joy":
				joy_center = e.position
				joy_pos = e.position
			elif role != "look":
				player.press(role, true)
			elif player.hp <= 0:
				player.respawn()
		else:
			var role: String = touches.get(e.index, "")
			touches.erase(e.index)
			if role == "joy":
				player.move_vec = Vector2.ZERO
				joy_pos = joy_center
			elif role != "look" and role != "":
				player.press(role, false)
	elif e is InputEventScreenDrag:
		var role: String = touches.get(e.index, "")
		if role == "joy":
			var d: Vector2 = e.position - joy_center
			var r := 90.0
			if d.length() > r:
				d = d.normalized() * r
			joy_pos = joy_center + d
			player.move_vec = d / r
		elif role == "look":
			player.rotate_look(e.relative)

func _process(delta: float) -> void:
	hitmark = max(0.0, hitmark - delta)
	_layout()
	queue_redraw()

func _t(txt: String, pos: Vector2, size: int = 30, col: Color = GOLD) -> void:
	draw_string(ThemeDB.fallback_font, pos, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)

func _draw() -> void:
	if player == null:
		return
	var s := get_viewport_rect().size
	if player.hurt_t > 0.0:
		draw_rect(Rect2(Vector2.ZERO, s), Color(1, 0, 0, player.hurt_t))
	# прицел
	var c := s / 2
	var col := Color(1, 0.2, 0.2) if hitmark > 0.0 else Color(0.2, 1, 0.2)
	draw_line(c + Vector2(-14, 0), c + Vector2(-5, 0), col, 2.0)
	draw_line(c + Vector2(5, 0), c + Vector2(14, 0), col, 2.0)
	draw_line(c + Vector2(0, -14), c + Vector2(0, -5), col, 2.0)
	draw_line(c + Vector2(0, 5), c + Vector2(0, 14), col, 2.0)
	# HUD
	_t("$%d" % player.money, Vector2(s.x * 0.20, 40), 34)
	_t("KILLS %d" % player.kills, Vector2(s.x * 0.45, 40), 30)
	_t("HP %d   AP %d" % [player.hp, player.armor], Vector2(s.x * 0.30, s.y - 24), 34)
	var w = player.weapons[player.cur]
	var amm: String = "RELOAD..." if player.reloading else "%d / %d" % [player.ammos[player.cur], player.reserves[player.cur]]
	_t(w.name, Vector2(s.x * 0.30, s.y - 68), 26)
	_t(amm, Vector2(s.x * 0.50, s.y - 24), 34)
	# джойстик
	draw_circle(joy_center, 90, Color(1, 1, 1, 0.08))
	draw_arc(joy_center, 90, 0, TAU, 40, Color(1, 1, 1, 0.4), 2.0)
	draw_circle(joy_pos, 38, Color(1, 1, 1, 0.3))
	# кнопки
	for k in buttons:
		var b = buttons[k]
		draw_circle(b[0], b[1], Color(1, 1, 1, 0.12))
		draw_arc(b[0], b[1], 0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
		_t(b[2], b[0] + Vector2(-b[1] * 0.55, 8), 22, Color(1, 1, 1, 0.8))
	if player.hp <= 0:
		draw_rect(Rect2(Vector2.ZERO, s), Color(0, 0, 0, 0.5))
		_t("YOU DIED - TAP TO RESPAWN", Vector2(s.x * 0.28, s.y * 0.5), 44, Color(1, 0.3, 0.3))
